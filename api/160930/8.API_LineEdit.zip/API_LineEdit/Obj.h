#pragma once

#include "Define.h"

class CObj
{
protected:
	INFO	m_tInfo;
	float	fSpeed;

public:
	INFO GetInfo(void) const {return m_tInfo;}
	void SetPos(float _x, float _y) { m_tInfo.fX = _x; m_tInfo.fY = _y; }

public:
	virtual void Initialize(void)PURE;
	virtual int Progress(void)PURE;
	virtual void Render(HDC hdc)PURE;
	virtual void Release(void)PURE;

public:
	CObj(void);
	virtual ~CObj(void);

};
