#pragma once
class CObj;

template <typename T>
class CObjFactory
{
public:
	static CObj* CreateObj()
	{
		CObj* obj = new T;
		obj->Initialize();

		return obj;
	}
};
