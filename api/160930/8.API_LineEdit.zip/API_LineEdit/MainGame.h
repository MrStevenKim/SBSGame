#pragma once

#include "Define.h"

class CObj;

class CMainGame
{
private:
	HDC		m_hdc;
	list<CObj*> m_ObjList[OBJ_END];

public:
	void Initialize(void);
	void Progress(void);
	void Render(void);
	void Release(void);

public:
	CMainGame(void);
	~CMainGame(void);
};
