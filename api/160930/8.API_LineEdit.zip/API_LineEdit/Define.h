#pragma once

#define PURE =0

const int	WINCX = 800;
const int	WINCY = 600;

extern HWND		g_hWnd;

typedef struct tagInfo
{
	float		fX;
	float		fY;
	float		fCX;
	float		fCY;

	tagInfo() { }
	tagInfo(float _fx, float _fy, float _fcx, float _fcy)
		:fX(_fx), fY(_fy), fCX(_fcx), fCY(_fcy) { }
}INFO;


typedef struct tagLine
{
	POINTFLOAT	tLPoint;
	POINTFLOAT	tRPoint;

	tagLine(void) {}
	tagLine(POINTFLOAT _lpoint, POINTFLOAT _ropoint)
		: tLPoint(_lpoint), tRPoint(_ropoint)
	{

	}
}LINE;


template <typename T>
static inline void Safe_Delete(T& temp)
{
	if(temp)
	{
		delete temp;
		temp = NULL;
	}
}

enum OBJ
{
	OBJ_LINEEDIT,
	OBJ_END
};