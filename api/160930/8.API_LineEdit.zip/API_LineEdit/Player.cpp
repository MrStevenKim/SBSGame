#include "StdAfx.h"
#include "Player.h"

CPlayer::CPlayer(void)
{
}

CPlayer::~CPlayer(void)
{
}

void CPlayer::Initialize(void)
{
	m_tInfo = INFO(WINCX / 2.f, WINCY / 2.f, 100, 100);
	fSpeed = 10.f;
}

int CPlayer::Progress(void)
{
	CheckKey();
	return 0;
}

void CPlayer::Render(HDC hdc)
{
	Ellipse(hdc, 
		int(m_tInfo.fX - m_tInfo.fCX / 2),
		int(m_tInfo.fY - m_tInfo.fCY / 2),
		int(m_tInfo.fX + m_tInfo.fCX / 2),
		int(m_tInfo.fY + m_tInfo.fCY / 2));
}

void CPlayer::Release(void)
{

}

void CPlayer::CheckKey()
{
	if(GetAsyncKeyState(VK_LEFT))
		m_tInfo.fX -= fSpeed;
	if(GetAsyncKeyState(VK_RIGHT))
		m_tInfo.fX += fSpeed;
	if(GetAsyncKeyState(VK_UP))
		m_tInfo.fY -= fSpeed;
	if(GetAsyncKeyState(VK_DOWN))
		m_tInfo.fY += fSpeed;
}