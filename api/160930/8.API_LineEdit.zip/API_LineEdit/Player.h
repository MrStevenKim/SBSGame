#pragma once
#include "obj.h"

class CPlayer :
	public CObj
{
private:
	void CheckKey();

public:
	CPlayer(void);
	virtual ~CPlayer(void);
public:
	virtual void Initialize(void);
	virtual int Progress(void);
	virtual void Render(HDC hdc);
	virtual void Release(void);
};
