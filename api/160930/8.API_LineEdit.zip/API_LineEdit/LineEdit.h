#pragma once
#include "obj.h"

class CLineEdit : public CObj
{
private:
	bool	m_bStart;
	POINTFLOAT		m_tStartPoint;

	POINTFLOAT		m_tScrollPos;		// ȭ�� ��ũ��
	float			m_fSpeed;

	list<LINE*>		m_LineList;   // �� ��ǥ�� list �� ����.    LINE  <===[ struct ]

/*
	typedef struct tagLine
	{
		POINTFLOAT	tLPoint;	//  ���� ��ǥ 
		POINTFLOAT	tRPoint;	//	���� ��ǥ

		tagLine(void) {}
		tagLine(POINTFLOAT _lpoint, POINTFLOAT _ropoint)
			: tLPoint(_lpoint), tRPoint(_ropoint)
		{

		}
	} LINE;    <===[ struct ]
*/

public:
	void WriteData(void);  // ���� ����

public:
	virtual void Initialize(void);
	virtual int Progress(void);
	virtual void Render(HDC hdc);
	virtual void Release(void);

public:
	CLineEdit(void);
	virtual ~CLineEdit(void);
};
