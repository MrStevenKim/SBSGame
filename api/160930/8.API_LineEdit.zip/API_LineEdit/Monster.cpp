#include "StdAfx.h"
#include "Monster.h"

CMonster::CMonster(void)
{
}

CMonster::~CMonster(void)
{
}

void CMonster::Initialize(void)
{

}

int CMonster::Progress(void)
{
	return 0;
}

void CMonster::Render(HDC hdc)
{

}

void CMonster::Release(void)
{

}