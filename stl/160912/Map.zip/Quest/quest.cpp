#include <iostream>
#include <list>
#include <vector>
#include <map>
#include <string>

using namespace std;



int main()
{
	map<string, vector<int>> m_Map;
	multimap<string, vector<int>> m_MultiMap;

	vector<int> vecInt;

	vecInt.push_back(1);
	vecInt.push_back(2);
	vecInt.push_back(3);
	vecInt.push_back(4);
	vecInt.push_back(5);
	vecInt.push_back(6);




	/*m_MultiMap.insert(make_pair("Key1", vecInt));
	m_MultiMap.insert(make_pair("Key1", vecInt));
	m_MultiMap.insert(make_pair("Key1", vecInt));
	m_MultiMap.insert(make_pair("Key1", vecInt));
	m_MultiMap.insert(make_pair("Key1", vecInt));
	m_MultiMap.insert(make_pair("Key1", vecInt));*/
	// Ű���� �����ص� ��.



	/*m_Map.insert(make_pair("Key1", vecInt));
	m_Map.insert(make_pair("Key2", vecInt));
	m_Map.insert(make_pair("Key3", vecInt));*/
	// Ű���� �����ϸ� �����



	/*m_Map["Key1"].push_back(1);
	m_Map["Key1"].push_back(2);
	m_Map["Key1"].push_back(3);

	m_Map["Key2"].push_back(10);
	m_Map["Key2"].push_back(20);
	m_Map["Key2"].push_back(30);

	m_Map["Key3"].push_back(100);
	m_Map["Key3"].push_back(200);
	m_Map["Key3"].push_back(300);*/
	//	 for(vector<int>::iterator iter = )    �ȵǴ� ��











	//���� 
	for(multimap<string, vector<int>>::iterator iter = m_MultiMap.begin() ; iter != m_MultiMap.end() ; ++iter)
	{
		cout << iter->first <<endl;

		for(vector<int>::size_type i = 0;  i < (iter->second.size()) ; ++i)
		{  
			cout << "["<<iter->second[i] << "] " << iter->first << endl;
		}
		cout << endl;
	}



	for(map<string, vector<int>>::iterator iter = m_Map.begin() ; iter != m_Map.end() ; ++iter)
	{
		cout << iter->first <<endl;

		for(vector<int>::size_type i = 0;  i < (iter->second.size()) ; ++i)
		{  
			cout << "["<<iter->second[i] << "] " << iter->first << endl;
		}
		cout << endl;
	}




	return 0;
}