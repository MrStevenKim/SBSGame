#pragma once
#include "Scene.h"
#include "SceneMgr.h"

class CInput : public CScene
{
private:
	
	int t_kor;
	int t_eng;
	int t_math;
	int t_total;
	float t_average;
	char name[10];
	int t_num;

public:
	
	

public:
	virtual void Initialize();
	virtual void Progress();
	virtual void Render();
	virtual void Release();

	
public:
	CInput();
	virtual ~CInput();
};

