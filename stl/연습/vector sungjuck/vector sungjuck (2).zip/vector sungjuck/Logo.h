#pragma once
#include "Scene.h"
#include "SceneMgr.h"
class CLogo:public CScene
{
private:
	char* m_pChar[10];
	DWORD m_tCount;
public:
	virtual void Initialize();
	virtual void Progress();
	virtual void Render();
	virtual void Release();

public:
	CLogo();
	virtual ~CLogo();
};

