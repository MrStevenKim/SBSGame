#include "High.h"



CHigh::CHigh()
{
}


CHigh::~CHigh()
{
}
