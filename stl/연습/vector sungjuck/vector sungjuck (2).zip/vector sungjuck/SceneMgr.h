#pragma once
#include "Include.h"
class CScene;
class CSceneMgr
{
private:
	static CSceneMgr* m_pInstance;

public:
	static CSceneMgr* GetInstance()
	{
		if (m_pInstance == NULL)
			m_pInstance = new CSceneMgr;
		return m_pInstance;
	}
private:
	CScene* m_pSceneMgr;
public:
	void SetScene(STATEID _estateid);
	void Progress();
	void Render();
	void Release();
	

	CSceneMgr();
	
public:	
	~CSceneMgr();
};

