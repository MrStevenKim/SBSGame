#include "Low.h"



CLow::CLow()
{
}


CLow::~CLow()
{
}
