#pragma once
class CLow
{
public:
	CLow();
	~CLow();
};

