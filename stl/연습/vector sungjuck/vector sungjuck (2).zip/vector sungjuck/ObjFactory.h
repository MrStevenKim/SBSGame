#pragma once
#include "Obj.h"
#include "Student.h"

class CObjFactory
{
public:
	static CObj* CreateStudent(char* t_iName,int t_iKor,int t_iEng ,int t_iMath,int t_iTotal,float t_iAverage)
	{
	
		
		CObj* pObj = new CStudent;
		pObj->Initialize();
		pObj->SetInfo(t_iName, t_iKor, t_iEng, t_iMath, t_iTotal, t_iAverage);
	

		return pObj;
	}
};