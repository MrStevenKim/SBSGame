#pragma once
#include "Scene.h"
class CSelect:public CScene
{
private:
	char* menu1;
	char* menu2;
	char* menu3;
	int num;

public:
	virtual void Initialize();
	virtual void Progress();
	virtual void Render();
	virtual void Release();

public:
	CSelect();
	virtual ~CSelect();
};

