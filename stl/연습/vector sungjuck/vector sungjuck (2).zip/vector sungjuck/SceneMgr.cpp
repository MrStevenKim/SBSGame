#include "SceneMgr.h"
#include "Include.h"
#include "Logo.h"
#include "Normal.h"
#include "Select.h"
#include "Low.h"
#include "High.h"
#include "Input.h"
CSceneMgr* CSceneMgr::m_pInstance = NULL;

void CSceneMgr::SetScene(STATEID _estateid)
{
	::Safe_Delete(m_pSceneMgr);

	switch (_estateid)
	{
	case IDS_LOGO:
		m_pSceneMgr = new CLogo;
		break;

	case IDS_INPUT:
		m_pSceneMgr = new CInput;
		break;

	case IDS_SELECT:
		m_pSceneMgr = new CSelect;
		break;
		
	/*case IDS_HIGH:
		m_pSceneMgr = new CHigh;
		break;

case IDS_LOW:
		m_pSceneMgr = new CLow;
		break;
		
		*/
	case IDS_NORMAL:
		m_pSceneMgr = new CNormal;
		break;
		
	
	}

	m_pSceneMgr->Initialize();
}





void CSceneMgr::Progress()
{
	m_pSceneMgr->Progress();
}

void CSceneMgr::Render()
{
	m_pSceneMgr->Render();
}

void CSceneMgr::Release()
{
	m_pSceneMgr->Release();
}

CSceneMgr::CSceneMgr()
	:m_pSceneMgr(NULL)
{
}


CSceneMgr::~CSceneMgr()
{
	Release();
}

//�̱�����.