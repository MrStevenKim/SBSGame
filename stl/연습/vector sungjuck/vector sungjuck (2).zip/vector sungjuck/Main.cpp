#include "Include.h"
#include "MainProgram.h"

using namespace std;
int main()
{
	CMainProgram Main;
	Main.Initialize();

	DWORD dwTime = GetTickCount();

	while (true)
	{
		Main.Progress();
		Main.Render();
	}


	return 0;
}