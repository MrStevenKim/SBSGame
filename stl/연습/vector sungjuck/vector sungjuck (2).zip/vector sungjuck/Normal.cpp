#include "Normal.h"
#include "Obj.h"
#include "Input.h"

void CNormal::Initialize()
{
	Progress();
}

void CNormal::Progress()
{
	Render();
}

void CNormal::Render()
{
	cout << "test";
}

void CNormal::Release()
{
}

CNormal::CNormal()
{
}


CNormal::~CNormal()
{
	Release();
}
