#pragma once
class CHigh
{
public:
	CHigh();
	~CHigh();
};

