#include "High.h"



void CHigh::Initialize()
{
	cout << "High �ʱ�ȭ" << endl;
	Progress();
}

void CHigh::Progress()
{
	cout << "High ����" << endl;
	Render();
}

void CHigh::Render()
{
	cout << "High ���" << endl;
	
	char ys;
	cout << "����Ͻðڽ��ϱ�? Y/N "<< endl;

		cin >> ys;
		if (ys == 'y' || ys == 'Y')
		{
			system("cls");
			CSceneMgr::GetInstance()->SetScene(IDS_SELECT);
		}
		else
		{
			system("cls");
			CSceneMgr::GetInstance()->SetScene(IDS_END);
		}
}

void CHigh::Release()
{
	


}

CHigh::CHigh()
{
}


CHigh::~CHigh()
{
	Release();
}
