#pragma once
enum STATEID
{
	IDS_LOGO,
	IDS_INPUT,
	IDS_SELECT,
	IDS_HIGH,
	IDS_LOW,
	IDS_NORMAL,
	IDS_END,
};