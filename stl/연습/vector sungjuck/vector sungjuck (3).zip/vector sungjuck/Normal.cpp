#include "Normal.h"
#include "Obj.h"
#include "Input.h"
#include "ObjFactory.h"
#include "Student.h"
void CNormal::Initialize()
{
	cout << "Normal �ʱ�ȭ" << endl;
	Progress();
}

void CNormal::Progress()
{
	cout << "Normal ����" << endl;
	
	Render();
}

void CNormal::Render()
{
	cout << "Normal ���" << endl;;
	
	char ys;
	cout << "����Ͻðڽ��ϱ�? Y/N " << endl;

	cin >> ys;
	if (ys == 'y' || ys == 'Y')
	{
		system("cls");
		CSceneMgr::GetInstance()->SetScene(IDS_SELECT);
	}
	else
	{
		system("cls");
		CSceneMgr::GetInstance()->SetScene(IDS_END);
	}
}

void CNormal::Release()
{
}

CNormal::CNormal()
{
}


CNormal::~CNormal()
{
	Release();
}
