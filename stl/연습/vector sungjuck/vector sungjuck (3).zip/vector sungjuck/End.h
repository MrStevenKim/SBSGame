#pragma once
#include "Scene.h"
#include "SceneMgr.h"
class CEnd : public CScene

{

public:
	virtual void Initialize();
	virtual void Progress();
	virtual void Render();
	virtual void Release();

public:
	CEnd();
virtual ~CEnd();
};

