#include "Low.h"



void CLow::Initialize()
{
	cout << "Low �ʱ�ȭ" << endl;
	Progress();
}

void CLow::Progress()
{
	cout << "Low ����" <<endl;

	Render();
}

void CLow::Render()
{
	cout << "Low ���"<<endl;

	

	char ys;
	cout << "����Ͻðڽ��ϱ�? Y/N " << endl;

	cin >> ys;

	if (ys == 'y' || ys == 'Y')
	{
		system("cls");
		CSceneMgr::GetInstance()->SetScene(IDS_SELECT);
	}
	else
	{
		system("cls");
		CSceneMgr::GetInstance()->SetScene(IDS_END);
	}
}

void CLow::Release()
{
}

CLow::CLow()
{
}


CLow::~CLow()
{
	Release();
}
